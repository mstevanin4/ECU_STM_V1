#ifndef UPDATES_H
#define UPDATES_H

void doUpdates();

#endif